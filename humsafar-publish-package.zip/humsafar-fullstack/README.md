# Humsafar full-stack starter

This folder contains the English Humsafar website and an API-connected mobile-friendly app, plus a Node.js/PostgreSQL backend. The website is served from the same origin as the API and app.

## Start locally with Docker

1. Install Docker Desktop.
2. Copy `.env.example` to `.env`.
3. Replace `POSTGRES_PASSWORD` with a long random hexadecimal password (hex avoids URL escaping problems). Replace `SESSION_SECRET` with a different random value of at least 32 characters.
4. From this folder, run `docker compose up --build`.
5. Open `http://localhost:3000` for the website or `http://localhost:3000/app` for the app.

To stop the services, run `docker compose down`. The database remains in the `humsafar_db` volume. To erase that volume, use `docker compose down -v`; that permanently deletes the local database.

## Run without Docker

Use Node.js 24 or newer and PostgreSQL 17. Create a PostgreSQL database and set `DATABASE_URL`, `SESSION_SECRET`, and `NODE_ENV=development`. Then run `npm install` and `npm start`. The server creates its tables on first start. The Docker image uses the current Node.js 26 LTS release.

## API included

- Account registration and login using a phone number and password.
- Server-side password hashing with Node's `scrypt` and timing-safe comparison.
- HttpOnly, SameSite session cookies; session tokens are stored as hashes and expire after seven days.
- Profile creation and editing, including age and match preferences.
- Searchable profiles, connection requests, accept/decline, and chats for accepted connections.
- Message history, rate limits, origin checks for writes, basic security headers, profile reports, account data export, and password-confirmed account deletion.

Passwords are never sent back to the browser. The app does not store account credentials in browser storage.

## Hosting

The Docker image can be deployed to a container host with a managed PostgreSQL database. Configure `NODE_ENV=production`, `DATABASE_URL`, `SESSION_SECRET`, `PORT`, and `PG_POOL_MAX` in that host's secret/environment settings. The host must provide HTTPS and persistent PostgreSQL backups. Do not commit `.env` or production secrets.

### Render preview

`render.yaml` defines a no-cost preview web service and Postgres database. To use it, put the contents of this project folder at the root of a GitHub repository, then create a Blueprint in Render from that repository. Render assigns an `onrender.com` address. The free database expires after 30 days and free services can sleep or hit monthly limits, so this setup is only for preview; do not store real member data in it. See [Render's free service limits](https://render.com/docs/free). No paid plan is configured by this Blueprint.

The files are prepared for hosting, but they are not published yet. Publishing requires a GitHub repository and a Render account connection. A custom domain can be connected later. Docker and PostgreSQL are unavailable in this workspace, so the database-backed server could not be run here; its JavaScript syntax was checked. The included rate limiter uses in-memory storage; use a shared store such as Redis before running multiple app instances.

## Before opening to the public

This is a functional MVP starter, not a complete regulated matrimonial service. Phone OTP verification, email/SMS notifications, profile photo/video uploads, moderation operations, account deletion/export controls, privacy policy, terms of service, and production monitoring are not integrated. Add these services and review the data-protection requirements for the countries where Humsafar will operate before inviting real members.

Sample photos on the landing page load from Unsplash and need an internet connection. New member profiles appear after users register; the backend does not seed fake accounts.
