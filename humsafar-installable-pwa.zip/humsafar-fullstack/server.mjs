import express from "express";
import helmet from "helmet";
import rateLimit from "express-rate-limit";
import pg from "pg";
import {
  createHmac,
  randomBytes,
  randomUUID,
  scrypt as scryptCallback,
  timingSafeEqual,
} from "node:crypto";
import { promisify } from "node:util";
import path from "node:path";
import { fileURLToPath } from "node:url";

const { Pool } = pg;
const scrypt = promisify(scryptCallback);
const here = path.dirname(fileURLToPath(import.meta.url));
const app = express();
const isProduction = process.env.NODE_ENV === "production";
const port = Number(process.env.PORT || 3000);
const sessionSecret = process.env.SESSION_SECRET || "local-development-only-change-before-deploy";

if (!process.env.DATABASE_URL) {
  throw new Error("DATABASE_URL is required. See .env.example and README.md.");
}
if (isProduction && (!process.env.SESSION_SECRET || process.env.SESSION_SECRET.length < 32)) {
  throw new Error("Set SESSION_SECRET to a random value of at least 32 characters.");
}

const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  max: Number(process.env.PG_POOL_MAX || 10),
  connectionTimeoutMillis: 8000,
  idleTimeoutMillis: 10000,
});

app.disable("x-powered-by");
app.set("trust proxy", 1);
app.use(helmet({
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"],
      baseUri: ["'self'"],
      connectSrc: ["'self'"],
      fontSrc: ["'self'", "data:"],
      formAction: ["'self'"],
      frameAncestors: ["'none'"],
      imgSrc: ["'self'", "data:", "https://images.unsplash.com"],
      objectSrc: ["'none'"],
      scriptSrc: ["'self'", "'unsafe-inline'"],
      styleSrc: ["'self'", "'unsafe-inline'"],
      workerSrc: ["'self'"],
      upgradeInsecureRequests: isProduction ? [] : null,
    },
  },
}));
app.use(express.json({ limit: "20kb", strict: true }));

const rateLimitHandler = (_req,res) => res.status(429).json({error:"Too many requests. Please wait and try again."});
const apiLimiter = rateLimit({ windowMs: 15 * 60 * 1000, limit: 300, standardHeaders: "draft-8", legacyHeaders: false, handler:rateLimitHandler });
const authLimiter = rateLimit({ windowMs: 15 * 60 * 1000, limit: 10, standardHeaders: "draft-8", legacyHeaders: false, handler:rateLimitHandler });
app.use("/api", apiLimiter);

app.use("/api", (req, res, next) => {
  if (["POST", "PATCH", "DELETE"].includes(req.method)) {
    const origin = req.get("origin");
    if (!origin || origin !== `${req.protocol}://${req.get("host")}`) {
      return res.status(403).json({ error: "Request origin could not be verified." });
    }
  }
  next();
});

const schema = `
CREATE TABLE IF NOT EXISTS users (
  id UUID PRIMARY KEY,
  phone VARCHAR(16) NOT NULL UNIQUE,
  password_salt TEXT NOT NULL,
  password_hash TEXT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS profiles (
  user_id UUID PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
  display_name VARCHAR(80) NOT NULL,
  age SMALLINT NOT NULL CHECK (age BETWEEN 18 AND 100),
  city VARCHAR(100) NOT NULL,
  gender VARCHAR(24) NOT NULL CHECK (gender IN ('woman','man','self_described')),
  seeking VARCHAR(16) NOT NULL CHECK (seeking IN ('women','men','all')),
  education VARCHAR(120) NOT NULL DEFAULT '',
  profession VARCHAR(120) NOT NULL DEFAULT '',
  bio VARCHAR(1000) NOT NULL DEFAULT '',
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS sessions (
  token_hash CHAR(64) PRIMARY KEY,
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  expires_at TIMESTAMPTZ NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS sessions_expiry_idx ON sessions(expires_at);
CREATE TABLE IF NOT EXISTS connection_requests (
  id UUID PRIMARY KEY,
  requester_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  recipient_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  status VARCHAR(16) NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','accepted','declined')),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  CHECK (requester_id <> recipient_id),
  UNIQUE (requester_id, recipient_id)
);
CREATE INDEX IF NOT EXISTS connections_parties_idx ON connection_requests(requester_id, recipient_id, status);
CREATE TABLE IF NOT EXISTS messages (
  id UUID PRIMARY KEY,
  connection_id UUID NOT NULL REFERENCES connection_requests(id) ON DELETE CASCADE,
  sender_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  body VARCHAR(2000) NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS messages_connection_created_idx ON messages(connection_id, created_at);
CREATE TABLE IF NOT EXISTS reports (
  id UUID PRIMARY KEY,
  reporter_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  target_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  reason VARCHAR(500) NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  CHECK (reporter_id <> target_id)
);
`;

async function migrate() {
  await pool.query(schema);
  await pool.query("DELETE FROM sessions WHERE expires_at < now()");
}

const hashToken = (token) => createHmac("sha256",sessionSecret).update(token).digest("hex");
const cleanText = (value, max) => typeof value === "string" ? value.trim().slice(0, max) : "";
const phoneFormat = /^\+?[1-9]\d{6,14}$/;
const uuidFormat = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;

function cookieValue(req, name) {
  const entry = (req.headers.cookie || "").split(";").map((part) => part.trim()).find((part) => part.startsWith(`${name}=`));
  return entry ? decodeURIComponent(entry.slice(name.length + 1)) : "";
}

function setSessionCookie(res, token) {
  const parts = [`humsafar_session=${encodeURIComponent(token)}`, "Path=/", "HttpOnly", "SameSite=Lax", "Max-Age=604800"];
  if (isProduction) parts.push("Secure");
  res.setHeader("Set-Cookie", parts.join("; "));
}

function clearSessionCookie(res) {
  const parts = ["humsafar_session=", "Path=/", "HttpOnly", "SameSite=Lax", "Max-Age=0"];
  if (isProduction) parts.push("Secure");
  res.setHeader("Set-Cookie", parts.join("; "));
}

async function issueSession(userId, res) {
  const token = randomBytes(32).toString("base64url");
  await pool.query(
    "INSERT INTO sessions(token_hash,user_id,expires_at) VALUES($1,$2,now()+interval '7 days')",
    [hashToken(token), userId],
  );
  setSessionCookie(res, token);
}

async function requireUser(req, res, next) {
  try {
    const token = cookieValue(req, "humsafar_session");
    if (!token) return res.status(401).json({ error: "Please log in to continue." });
    const result = await pool.query(
      `SELECT u.id,u.phone,p.display_name,p.age,p.city,p.gender,p.seeking,p.education,p.profession,p.bio
       FROM sessions s JOIN users u ON u.id=s.user_id JOIN profiles p ON p.user_id=u.id
       WHERE s.token_hash=$1 AND s.expires_at>now()`, [hashToken(token)],
    );
    if (!result.rowCount) {
      clearSessionCookie(res);
      return res.status(401).json({ error: "Your session expired. Please log in again." });
    }
    req.user = result.rows[0];
    next();
  } catch (error) { next(error); }
}

const publicProfile = (row) => ({
  id: row.user_id || row.id,
  name: row.display_name,
  age: row.age,
  city: row.city,
  gender: row.gender,
  education: row.education,
  profession: row.profession,
  bio: row.bio,
});

const accountProfile = (row) => ({
  id: row.id || row.user_id,
  phone: row.phone,
  displayName: row.display_name || row.displayName,
  age: row.age,
  city: row.city,
  gender: row.gender,
  seeking: row.seeking,
  education: row.education || "",
  profession: row.profession || "",
  bio: row.bio || "",
});

function validateProfile(input) {
  const displayName = cleanText(input?.displayName, 80);
  const age = Number(input?.age);
  const city = cleanText(input?.city, 100);
  const gender = input?.gender;
  const seeking = input?.seeking;
  const education = cleanText(input?.education, 120);
  const profession = cleanText(input?.profession, 120);
  const bio = cleanText(input?.bio, 1000);
  if (displayName.length < 2) return { error: "Enter a name with at least 2 characters." };
  if (!Number.isInteger(age) || age < 18 || age > 100) return { error: "You must be 18 or older." };
  if (city.length < 2) return { error: "Enter a city." };
  if (!["woman", "man", "self_described"].includes(gender)) return { error: "Choose a profile gender." };
  if (!["women", "men", "all"].includes(seeking)) return { error: "Choose who you would like to meet." };
  return { value: { displayName, age, city, gender, seeking, education, profession, bio } };
}

app.get("/api/health", async (_req, res, next) => {
  try { await pool.query("SELECT 1"); res.json({ status: "ok" }); }
  catch (error) { next(error); }
});

app.post("/api/auth/register", authLimiter, async (req, res, next) => {
  const phone = cleanText(req.body?.phone, 16).replace(/[\s()-]/g, "");
  const password = typeof req.body?.password === "string" ? req.body.password : "";
  const profile = validateProfile(req.body?.profile);
  if (!phoneFormat.test(phone)) return res.status(400).json({ error: "Enter a valid international phone number." });
  if (password.length < 10 || password.length > 128) return res.status(400).json({ error: "Password must be at least 10 characters." });
  if (profile.error) return res.status(400).json({ error: profile.error });
  const client = await pool.connect();
  try {
    await client.query("BEGIN");
    const userId = randomUUID();
    const sessionToken = randomBytes(32).toString("base64url");
    const salt = randomBytes(16).toString("hex");
    const passwordHash = (await scrypt(password, salt, 64)).toString("hex");
    await client.query("INSERT INTO users(id,phone,password_salt,password_hash) VALUES($1,$2,$3,$4)", [userId, phone, salt, passwordHash]);
    const p = profile.value;
    await client.query(
      `INSERT INTO profiles(user_id,display_name,age,city,gender,seeking,education,profession,bio)
       VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9)`,
      [userId,p.displayName,p.age,p.city,p.gender,p.seeking,p.education,p.profession,p.bio],
    );
    await client.query(
      "INSERT INTO sessions(token_hash,user_id,expires_at) VALUES($1,$2,now()+interval '7 days')",
      [hashToken(sessionToken),userId],
    );
    await client.query("COMMIT");
    setSessionCookie(res,sessionToken);
    res.status(201).json({ user: accountProfile({ id:userId, phone, ...p, display_name:p.displayName }) });
  } catch (error) {
    await client.query("ROLLBACK").catch(() => {});
    if (error.code === "23505") return res.status(409).json({ error: "An account with this phone number already exists." });
    next(error);
  } finally { client.release(); }
});

app.post("/api/auth/login", authLimiter, async (req, res, next) => {
  try {
    const phone = cleanText(req.body?.phone, 16).replace(/[\s()-]/g, "");
    const password = typeof req.body?.password === "string" ? req.body.password : "";
    if (!phoneFormat.test(phone) || !password) return res.status(400).json({ error: "Enter your phone number and password." });
    const result = await pool.query("SELECT id,phone,password_salt,password_hash FROM users WHERE phone=$1", [phone]);
    if (!result.rowCount) return res.status(401).json({ error: "Phone number or password is incorrect." });
    const user = result.rows[0];
    const supplied = await scrypt(password, user.password_salt, 64);
    const stored = Buffer.from(user.password_hash, "hex");
    if (stored.length !== supplied.length || !timingSafeEqual(stored, supplied)) return res.status(401).json({ error: "Phone number or password is incorrect." });
    await issueSession(user.id, res);
    const profile = await pool.query("SELECT * FROM profiles WHERE user_id=$1", [user.id]);
    res.json({ user: accountProfile({ id:user.id, phone:user.phone, ...profile.rows[0] }) });
  } catch (error) { next(error); }
});

app.post("/api/auth/logout", requireUser, async (req, res, next) => {
  try {
    const token = cookieValue(req, "humsafar_session");
    await pool.query("DELETE FROM sessions WHERE token_hash=$1", [hashToken(token)]);
    clearSessionCookie(res);
    res.json({ ok: true });
  } catch (error) { next(error); }
});

app.get("/api/me", requireUser, (req, res) => {
  res.json({ user: accountProfile(req.user) });
});

app.patch("/api/me", requireUser, async (req, res, next) => {
  const profile = validateProfile(req.body);
  if (profile.error) return res.status(400).json({ error: profile.error });
  try {
    const p = profile.value;
    const result = await pool.query(
      `UPDATE profiles SET display_name=$2,age=$3,city=$4,gender=$5,seeking=$6,education=$7,profession=$8,bio=$9,updated_at=now()
       WHERE user_id=$1 RETURNING *`,
      [req.user.id,p.displayName,p.age,p.city,p.gender,p.seeking,p.education,p.profession,p.bio],
    );
    res.json({ user: accountProfile({ id:req.user.id, phone:req.user.phone, ...result.rows[0] }) });
  } catch (error) { next(error); }
});

app.get("/api/me/export", requireUser, async (req,res,next) => {
  try {
    const [profile,connections,messages] = await Promise.all([
      pool.query("SELECT * FROM profiles WHERE user_id=$1",[req.user.id]),
      pool.query(
        `SELECT id,requester_id,recipient_id,status,created_at,updated_at FROM connection_requests
         WHERE requester_id=$1 OR recipient_id=$1 ORDER BY created_at`,[req.user.id],
      ),
      pool.query(
        `SELECT m.id,m.connection_id,m.sender_id,m.body,m.created_at FROM messages m
         JOIN connection_requests c ON c.id=m.connection_id
         WHERE c.requester_id=$1 OR c.recipient_id=$1 ORDER BY m.created_at`,[req.user.id],
      ),
    ]);
    res.json({exportedAt:new Date().toISOString(),user:accountProfile({id:req.user.id,phone:req.user.phone,...profile.rows[0]}),connections:connections.rows,messages:messages.rows});
  } catch(error) { next(error); }
});

app.delete("/api/me", requireUser, async (req,res,next) => {
  try {
    const password = typeof req.body?.password === "string" ? req.body.password : "";
    if (!password) return res.status(400).json({error:"Enter your password to delete your account."});
    const credentials = await pool.query("SELECT password_salt,password_hash FROM users WHERE id=$1",[req.user.id]);
    if (!credentials.rowCount) return res.status(404).json({error:"Account not found."});
    const row=credentials.rows[0], supplied=await scrypt(password,row.password_salt,64), stored=Buffer.from(row.password_hash,"hex");
    if (stored.length!==supplied.length||!timingSafeEqual(stored,supplied)) return res.status(401).json({error:"Password is incorrect."});
    const token=cookieValue(req,"humsafar_session");
    await pool.query("DELETE FROM users WHERE id=$1",[req.user.id]);
    clearSessionCookie(res);
    if(token) await pool.query("DELETE FROM sessions WHERE token_hash=$1",[hashToken(token)]).catch(()=>{});
    res.json({ok:true});
  } catch(error) { next(error); }
});

app.get("/api/profiles", requireUser, async (req, res, next) => {
  try {
    const q = `%${cleanText(req.query.q, 80).replace(/[\\%_]/g, "")}%`;
    const city = cleanText(req.query.city, 100);
    const result = await pool.query(
      `SELECT p.user_id,p.display_name,p.age,p.city,p.gender,p.education,p.profession,p.bio
       FROM profiles p WHERE p.user_id<>$1 AND ($2='all' OR ($2='women' AND p.gender='woman') OR ($2='men' AND p.gender='man'))
       AND ($3='' OR p.city ILIKE $3) AND ($4='%%' OR concat_ws(' ',p.display_name,p.profession,p.education,p.city) ILIKE $4)
       ORDER BY p.updated_at DESC LIMIT 60`,
      [req.user.id, req.user.seeking, city, q],
    );
    const cityResult = await pool.query(
      `SELECT DISTINCT city FROM profiles WHERE user_id<>$1
       AND ($2='all' OR ($2='women' AND gender='woman') OR ($2='men' AND gender='man'))
       ORDER BY city`, [req.user.id,req.user.seeking],
    );
    res.json({ profiles: result.rows.map(publicProfile), cities:cityResult.rows.map((row)=>row.city) });
  } catch (error) { next(error); }
});

app.get("/api/profiles/:id", requireUser, async (req, res, next) => {
  if (!uuidFormat.test(req.params.id)) return res.status(400).json({error:"Choose a valid profile."});
  try {
    const result = await pool.query(
      `SELECT user_id,display_name,age,city,gender,education,profession,bio
       FROM profiles WHERE user_id=$1 AND user_id<>$2`, [req.params.id,req.user.id],
    );
    if (!result.rowCount) return res.status(404).json({ error:"Profile not found." });
    res.json({ profile:publicProfile(result.rows[0]) });
  } catch (error) { next(error); }
});

app.post("/api/connections", requireUser, async (req, res, next) => {
  const recipientId = cleanText(req.body?.recipientId, 36);
  if (!uuidFormat.test(recipientId)) return res.status(400).json({ error: "Choose a valid profile." });
  if (recipientId === req.user.id) return res.status(400).json({ error: "You cannot connect with your own profile." });
  try {
    const prior = await pool.query(
      `SELECT id,status,requester_id,recipient_id FROM connection_requests
       WHERE (requester_id=$1 AND recipient_id=$2) OR (requester_id=$2 AND recipient_id=$1)
       ORDER BY created_at DESC LIMIT 1`, [req.user.id,recipientId],
    );
    if (prior.rowCount) {
      const row = prior.rows[0];
      if (row.status === "accepted") return res.status(409).json({ error: "You are already connected." });
      if (row.status === "declined") {
        const retry = await pool.query(
          `UPDATE connection_requests SET requester_id=$2,recipient_id=$3,status='pending',updated_at=now()
           WHERE id=$1 AND status='declined' RETURNING id,status,created_at`, [row.id,req.user.id,recipientId],
        );
        return res.status(201).json({ connection:retry.rows[0] });
      }
      if (row.requester_id === recipientId && row.status === "pending") return res.status(409).json({ error: "This person has already sent you a request. Accept it in your requests." });
      return res.status(409).json({ error: "You have already sent a request to this profile." });
    }
    const result = await pool.query(
      `INSERT INTO connection_requests(id,requester_id,recipient_id) VALUES($1,$2,$3) RETURNING id,status,created_at`,
      [randomUUID(),req.user.id,recipientId],
    );
    res.status(201).json({ connection: result.rows[0] });
  } catch (error) {
    if (error.code === "23503") return res.status(404).json({ error: "Profile not found." });
    next(error);
  }
});

app.get("/api/connections", requireUser, async (req, res, next) => {
  try {
    const result = await pool.query(
      `SELECT c.id,c.status,c.created_at,c.requester_id,c.recipient_id,
       p.user_id,p.display_name,p.age,p.city,p.gender,p.education,p.profession,p.bio
       FROM connection_requests c
       JOIN profiles p ON p.user_id=CASE WHEN c.requester_id=$1 THEN c.recipient_id ELSE c.requester_id END
       WHERE c.requester_id=$1 OR c.recipient_id=$1 ORDER BY c.created_at DESC LIMIT 100`, [req.user.id],
    );
    res.json({ connections: result.rows.map((row) => ({
      id: row.id,status: row.status,createdAt: row.created_at,
      direction: row.recipient_id === req.user.id ? "incoming" : "outgoing",
      profile: publicProfile(row),
    })) });
  } catch (error) { next(error); }
});

app.patch("/api/connections/:id", requireUser, async (req, res, next) => {
  if (!uuidFormat.test(req.params.id)) return res.status(400).json({error:"Choose a valid request."});
  const status = req.body?.status;
  if (!["accepted","declined"].includes(status)) return res.status(400).json({ error: "Choose accept or decline." });
  try {
    const result = await pool.query(
      `UPDATE connection_requests SET status=$3,updated_at=now()
       WHERE id=$1 AND recipient_id=$2 AND status='pending' RETURNING id,status`,
      [req.params.id,req.user.id,status],
    );
    if (!result.rowCount) return res.status(404).json({ error: "Request not found or already handled." });
    res.json({ connection: result.rows[0] });
  } catch (error) { next(error); }
});

async function acceptedConnection(connectionId, userId) {
  if (!uuidFormat.test(connectionId)) return undefined;
  const result = await pool.query(
    "SELECT id,requester_id,recipient_id FROM connection_requests WHERE id=$1 AND status='accepted' AND (requester_id=$2 OR recipient_id=$2)",
    [connectionId,userId],
  );
  return result.rows[0];
}

app.get("/api/chats", requireUser, async (req, res, next) => {
  try {
    const result = await pool.query(
      `SELECT c.id,c.created_at, p.user_id,p.display_name,p.age,p.city,p.gender,p.education,p.profession,p.bio,
       m.body AS last_message,m.created_at AS last_message_at
       FROM connection_requests c
       JOIN profiles p ON p.user_id=CASE WHEN c.requester_id=$1 THEN c.recipient_id ELSE c.requester_id END
       LEFT JOIN LATERAL (SELECT body,created_at FROM messages WHERE connection_id=c.id ORDER BY created_at DESC LIMIT 1) m ON true
       WHERE c.status='accepted' AND (c.requester_id=$1 OR c.recipient_id=$1)
       ORDER BY COALESCE(m.created_at,c.created_at) DESC`, [req.user.id],
    );
    res.json({ chats: result.rows.map((row) => ({ id:row.id,profile:publicProfile(row),lastMessage:row.last_message||"",updatedAt:row.last_message_at||row.created_at })) });
  } catch (error) { next(error); }
});

app.get("/api/chats/:id/messages", requireUser, async (req, res, next) => {
  try {
    const connection = await acceptedConnection(req.params.id, req.user.id);
    if (!connection) return res.status(404).json({ error: "Chat not found." });
    const result = await pool.query(
      `SELECT id,sender_id,body,created_at FROM messages WHERE connection_id=$1
       ORDER BY created_at DESC LIMIT 100`, [connection.id],
    );
    res.json({ messages: result.rows.reverse().map((m) => ({ id:m.id,senderId:m.sender_id,text:m.body,createdAt:m.created_at })) });
  } catch (error) { next(error); }
});

app.post("/api/chats/:id/messages", requireUser, async (req, res, next) => {
  const body = cleanText(req.body?.text, 2000);
  if (!body) return res.status(400).json({ error: "Write a message first." });
  try {
    const connection = await acceptedConnection(req.params.id, req.user.id);
    if (!connection) return res.status(404).json({ error: "Chat not found." });
    const result = await pool.query(
      "INSERT INTO messages(id,connection_id,sender_id,body) VALUES($1,$2,$3,$4) RETURNING id,sender_id,body,created_at",
      [randomUUID(),connection.id,req.user.id,body],
    );
    const m = result.rows[0];
    res.status(201).json({ message: { id:m.id,senderId:m.sender_id,text:m.body,createdAt:m.created_at } });
  } catch (error) { next(error); }
});

app.post("/api/reports", requireUser, async (req, res, next) => {
  const targetId = cleanText(req.body?.targetId, 36);
  const reason = cleanText(req.body?.reason, 500);
  if (!uuidFormat.test(targetId) || targetId === req.user.id || reason.length < 5) return res.status(400).json({ error: "Select a profile and provide a brief reason." });
  try {
    await pool.query("INSERT INTO reports(id,reporter_id,target_id,reason) VALUES($1,$2,$3,$4)", [randomUUID(),req.user.id,targetId,reason]);
    res.status(201).json({ ok: true });
  } catch (error) {
    if (error.code === "23503") return res.status(404).json({ error: "Profile not found." });
    next(error);
  }
});

app.use("/api", (_req,res) => res.status(404).json({ error: "API route not found." }));
app.use(express.static(path.join(here,"public"), { index:"index.html", maxAge:isProduction?"1h":0 }));
app.get("/app", (_req,res) => res.sendFile(path.join(here,"public","app.html")));
app.get("/app.html", (_req,res) => res.sendFile(path.join(here,"public","app.html")));
app.get("/{*path}", (_req,res) => res.sendFile(path.join(here,"public","index.html")));

app.use((error,_req,res,_next) => {
  console.error(error);
  if (res.headersSent) return;
  if (error.type === "entity.parse.failed" || error.status === 400) return res.status(400).json({error:"Request body is not valid JSON."});
  res.status(500).json({ error: "Something went wrong. Please try again." });
});

await migrate();
const sessionCleanup = setInterval(() => {
  pool.query("DELETE FROM sessions WHERE expires_at < now()").catch((error)=>console.error("Session cleanup failed",error));
}, 6 * 60 * 60 * 1000);
sessionCleanup.unref();
const server = app.listen(port,"0.0.0.0",(error) => {
  if (error) throw error;
  console.log(`Humsafar is listening on port ${port}`);
});

async function shutdown() {
  server.close(async () => { await pool.end(); process.exit(0); });
  setTimeout(() => process.exit(1),10000).unref();
}
process.on("SIGTERM",shutdown);
process.on("SIGINT",shutdown);
