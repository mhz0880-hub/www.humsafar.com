# Humsafar को फोन में install करने का तरीका

यह **PWA** है—वेबसाइट जैसा app जिसे फोन की home screen पर install किया जा सकता है। यह Android APK नहीं है।

## पहले ज़रूरी बात

Install करने के लिए Humsafar को HTTPS वाले website address पर publish करना होगा। ZIP या सीधे HTML file खोलकर install नहीं किया जा सकता। Service worker केवल HTTPS या localhost पर काम करता है।

## Android

1. Publish होने के बाद Chrome में Humsafar का `/app` address खोलें।
2. App का **Install** button दबाएँ। अगर वह prompt न दिखाए, Chrome menu `⋮` खोलें और **Install app** या **Add to Home screen** चुनें।
3. Home screen पर Humsafar icon से app खोलें।

## iPhone

1. Safari में Humsafar का `/app` address खोलें।
2. **Share** बटन दबाएँ और **Add to Home Screen** चुनें।
3. **Add** दबाएँ।

App का खोलने वाला हिस्सा offline cache हो सकता है। Login, profiles, connection requests और chats चलाने के लिए internet और backend server चाहिए।

## Publish करने से पहले

इस package में Render का free preview setup है, पर इसे publish करने के लिए GitHub और Render accounts connect करने होंगे। Free database अस्थायी है; असली सदस्य data डालने से पहले persistent paid database, phone verification, privacy policy और moderation व्यवस्था जोड़ें।
