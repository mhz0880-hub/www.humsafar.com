# Humsafar — GitHub Pages upload

This folder is ready to publish as a static GitHub Pages website. The home page is `index.html`; `app.html` is a browser-only multilingual demo (English, Hindi and Urdu). Demo accounts and messages stay in that browser on that device. This is not the connected live-members app and should not be used for real member data.

## Upload directly to GitHub

1. Create a new GitHub repository.
2. Open the repository and choose **Add file → Upload files**.
3. Extract this ZIP on your computer, then upload the **contents of this folder** so `index.html`, `app.html` and `404.html` are at the repository's top level.
4. Commit the uploaded files.
5. In the repository, open **Settings → Pages**. Under **Build and deployment**, choose **Deploy from a branch**, select the `main` branch and `/(root)`, then save.
6. Wait for GitHub Pages to show the published address. Open that address; the homepage is `index.html`.

All internal page links use `app.html` and section links, so they work on both a `username.github.io` site and a project site under `/repository-name/`. The included `404.html` offers a clear way back if someone enters an unknown address.

The public demo website does not use a server or database. The separate full-stack project is in the Humsafar source package for deployment on a Node/PostgreSQL host.
